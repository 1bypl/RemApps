# Zrzuty ekranu do README

Cztery pliki PNG zostały już dodane (zrzuty z Fedory 45 / KDE Plasma):

| Plik | Zawartość |
|---|---|
| `programy.png` | lista zainstalowanych programów z ikonami i przyciskami „Usuń" |
| `czyszczenie.png` | zakładka czyszczenia z zaznaczonymi kategoriami |
| `ustawienia.png` | ustawienia języka, motywu, trybów wyszukiwania i trybu symulacji |
| `oprogramie.png` | zakładka „O programie" z logo krokodyla |

Obrazy są wstawione do głównego `README.md` przez skrypt
`github/przygotuj.sh` jako `github/screenshots/*.png`.

Jeśli zechcesz je kiedyś odnowić: na Fedorze KDE służy do tego
`Print Screen`, `Alt + Print Screen` albo program **Spectacle**.

Autor projektu: **1bypl** — https://github.com/1bypl/RemApps
