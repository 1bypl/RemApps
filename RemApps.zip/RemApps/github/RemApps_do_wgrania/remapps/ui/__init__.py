"""Interfejs graficzny RemApps (PySide6)."""
