"""Wewnętrzna logika RemApps (niezależna od interfejsu)."""
