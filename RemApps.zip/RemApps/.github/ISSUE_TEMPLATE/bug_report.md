---
name: Zgłoszenie błędu
about: Zgłoś problem z działaniem RemApps
title: "[BŁĄD] "
labels: bug
assignees: ''
---

**Opis problemu**
Krótko opisz, co się dzieje.

**Jak to odtworzyć**
1. Otwórz RemApps...
2. Kliknij...
3. Zobacz błąd...

**Oczekiwane zachowanie**
Co powinno się stać?

**Moje środowisko**
- System: [np. Fedora 45 KDE / Ubuntu 24.04]
- Wersja RemApps: [np. 1.0.0]
- Wersja Pythona: [np. 3.13]

**Log / zrzut ekranu**
Wklej treść okna raportu lub dołącz zrzut ekranu.

**⚠️ Uwaga:** Nie wysyłaj haseł ani prywatnych danych.
